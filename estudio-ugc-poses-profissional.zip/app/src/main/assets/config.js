// Preencha adminUrl com o endereço do Apps Script (veja LEIA-ME-ACESSO.txt).
// Enquanto estiver vazio, os acessos ficam guardados no celular e são enviados depois.
window.APP_CONFIG = {
  adminUrl: "",
  token: "troque-por-uma-senha-sua"
};
